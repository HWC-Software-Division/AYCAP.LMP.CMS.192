SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_OM_UpsertABVariantData]
		@ABTestID int,
		@VariantsTable [Type_OM_ABVariantDataTable] READONLY
	AS
	BEGIN	
		-- SET XACT_ABORT - Always abort execution on unexpected errors - do not persist incorrect data
		-- SET NOCOUNT ON - Added to prevent extra result sets from interfering with SELECT statements.
		SET XACT_ABORT, NOCOUNT ON

		BEGIN TRY
			BEGIN TRANSACTION

				DELETE FROM [OM_ABVariantData] WHERE [ABVariantTestID] = @ABTestID AND NOT EXISTS (SELECT 1 FROM @VariantsTable t WHERE [OM_ABVariantData].[ABVariantGUID] = t.[ABVariantGUID])
		
				UPDATE [OM_ABVariantData]
				SET [ABVariantDisplayName] = t.[ABVariantDisplayName], 
					[ABVariantIsOriginal] = t.[ABVariantIsOriginal]
				FROM @VariantsTable as t
				WHERE [OM_ABVariantData].[ABVariantTestID] = @ABTestID AND [OM_ABVariantData].[ABVariantGUID] = t.[ABVariantGUID]

				INSERT INTO [OM_ABVariantData]
					   ([ABVariantDisplayName]
					   ,[ABVariantGUID]
					   ,[ABVariantIsOriginal]
					   ,[ABVariantTestID])
				SELECT [ABVariantDisplayName], [ABVariantGUID], [ABVariantIsOriginal], @ABTestID
				FROM @VariantsTable t WHERE NOT EXISTS (SELECT 1 FROM [OM_ABVariantData] d WHERE d.[ABVariantTestID] = @ABTestID AND t.[ABVariantGUID] = d.[ABVariantGUID])

			COMMIT TRANSACTION		
		END TRY
		BEGIN CATCH
			IF @@trancount > 0 ROLLBACK TRANSACTION
			
			-- Get the details of the error that invoked the CATCH block
			 DECLARE
			  @ErMessage NVARCHAR(2048),
			  @ErSeverity INT,
			  @ErState INT
	 
			 SELECT
			  @ErMessage = ERROR_MESSAGE(),
			  @ErSeverity = ERROR_SEVERITY(),
			  @ErState = ERROR_STATE()
	 
			 RAISERROR (@ErMessage,
						 @ErSeverity,
						 @ErState )
		END CATCH
	END
GO
