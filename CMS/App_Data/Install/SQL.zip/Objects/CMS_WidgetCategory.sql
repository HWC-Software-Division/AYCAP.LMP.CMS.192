SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_WidgetCategory](
	[WidgetCategoryID] [int] IDENTITY(1,1) NOT NULL,
	[WidgetCategoryName] [nvarchar](100) NOT NULL,
	[WidgetCategoryDisplayName] [nvarchar](100) NOT NULL,
	[WidgetCategoryParentID] [int] NULL,
	[WidgetCategoryPath] [nvarchar](450) NOT NULL,
	[WidgetCategoryLevel] [int] NOT NULL,
	[WidgetCategoryChildCount] [int] NULL,
	[WidgetCategoryWidgetChildCount] [int] NULL,
	[WidgetCategoryImagePath] [nvarchar](450) NULL,
	[WidgetCategoryGUID] [uniqueidentifier] NOT NULL,
	[WidgetCategoryLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_WidgetCategory] PRIMARY KEY NONCLUSTERED 
(
	[WidgetCategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE CLUSTERED INDEX [IX_CMS_WidgetCategory_CategoryPath] ON [dbo].[CMS_WidgetCategory]
(
	[WidgetCategoryPath] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_WidgetCategory_WidgetCategoryParentID] ON [dbo].[CMS_WidgetCategory]
(
	[WidgetCategoryParentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_WidgetCategory]  WITH CHECK ADD  CONSTRAINT [FK_CMS_WidgetCategory_WidgetCategoryParentID_CMS_WidgetCategory] FOREIGN KEY([WidgetCategoryParentID])
REFERENCES [dbo].[CMS_WidgetCategory] ([WidgetCategoryID])
GO
ALTER TABLE [dbo].[CMS_WidgetCategory] CHECK CONSTRAINT [FK_CMS_WidgetCategory_WidgetCategoryParentID_CMS_WidgetCategory]
GO
ALTER TABLE [dbo].[CMS_WidgetCategory]  WITH CHECK ADD  CONSTRAINT [CK_CMS_WidgetCategory_WidgetCategoryLevel] CHECK  (([WidgetCategoryLevel]>=(0)))
GO
ALTER TABLE [dbo].[CMS_WidgetCategory] CHECK CONSTRAINT [CK_CMS_WidgetCategory_WidgetCategoryLevel]
GO
