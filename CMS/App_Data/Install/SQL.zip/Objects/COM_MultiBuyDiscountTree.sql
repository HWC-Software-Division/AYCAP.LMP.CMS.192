SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_MultiBuyDiscountTree](
	[MultiBuyDiscountID] [int] NOT NULL,
	[NodeID] [int] NOT NULL,
	[NodeIncluded] [bit] NOT NULL,
 CONSTRAINT [PK_COM_MultiBuyDiscountTree] PRIMARY KEY CLUSTERED 
(
	[MultiBuyDiscountID] ASC,
	[NodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_MultiBuyDiscountTree_NodeID] ON [dbo].[COM_MultiBuyDiscountTree]
(
	[NodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountTree] ADD  CONSTRAINT [DEFAULT_COM_MultiBuyDiscountTree_NodeID]  DEFAULT ((0)) FOR [NodeID]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountTree] ADD  CONSTRAINT [DEFAULT_COM_MultiBuyDiscountTree_NodeIncluded]  DEFAULT ((1)) FOR [NodeIncluded]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountTree]  WITH CHECK ADD  CONSTRAINT [FK_COM_MultiBuyDiscountTree_MultiBuyDiscountID_COM_MultiBuyDiscount] FOREIGN KEY([MultiBuyDiscountID])
REFERENCES [dbo].[COM_MultiBuyDiscount] ([MultiBuyDiscountID])
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountTree] CHECK CONSTRAINT [FK_COM_MultiBuyDiscountTree_MultiBuyDiscountID_COM_MultiBuyDiscount]
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountTree]  WITH CHECK ADD  CONSTRAINT [FK_COM_MultiBuyDiscountTree_NodeID_CMS_Tree] FOREIGN KEY([NodeID])
REFERENCES [dbo].[CMS_Tree] ([NodeID])
GO
ALTER TABLE [dbo].[COM_MultiBuyDiscountTree] CHECK CONSTRAINT [FK_COM_MultiBuyDiscountTree_NodeID_CMS_Tree]
GO
