SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [View_CMS_Relationship_Joined] AS
SELECT	LeftTree.NodeID AS LeftNodeID, LeftTree.NodeGUID AS LeftNodeGUID, LeftTree.NodeName AS LeftNodeName, LeftTree.NodeSiteID as LeftNodeSiteID,
	CMS_RelationshipName.RelationshipName, CMS_RelationshipName.RelationshipNameID, RightTree.NodeID AS RightNodeID, RightTree.NodeGUID AS RightNodeGUID, 
	RightTree.NodeName AS RightNodeName, RightTree.NodeSiteID as RightNodeSiteID, CMS_RelationshipName.RelationshipDisplayName,
	CMS_Relationship.RelationshipCustomData, LeftTree.NodeClassID AS LeftClassID, RightTree.NodeClassID AS RightClassID, CMS_Relationship.RelationshipID, 
    CMS_Relationship.RelationshipOrder
FROM CMS_Relationship INNER JOIN
	CMS_Tree AS LeftTree ON CMS_Relationship.LeftNodeID = LeftTree.NodeID INNER JOIN
    CMS_Tree AS RightTree ON CMS_Relationship.RightNodeID = RightTree.NodeID INNER JOIN
    CMS_RelationshipName ON CMS_Relationship.RelationshipNameID = CMS_RelationshipName.RelationshipNameID
GO
