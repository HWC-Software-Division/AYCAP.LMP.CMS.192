SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_Analytics_ProcessLog]
  @LogHits Type_Analytics_LogHitsTable READONLY
AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @SiteID int
	DECLARE @CodeName nvarchar(400)
	DECLARE @Culture nvarchar(50)
	DECLARE @ObjectName nvarchar(1000)
	DECLARE @ObjectID int
	DECLARE @Hits int
	DECLARE @Value float
	DECLARE @HourStart datetime2(7)
	DECLARE @HourEnd datetime2(7)
	DECLARE @DayStart datetime2(7)
	DECLARE @DayEnd datetime2(7)
	DECLARE @WeekStart datetime2(7)
	DECLARE @WeekEnd datetime2(7)
	DECLARE @MonthStart datetime2(7)
	DECLARE @MonthEnd datetime2(7)
	DECLARE @YearStart datetime2(7)
	DECLARE @YearEnd datetime2(7)

	DECLARE TableCursor CURSOR 
	FOR (SELECT [SiteID], [CodeName], [Culture], [ObjectName], [ObjectId], [Hits], [Value],
				[HourStart], [HourEnd], [DayStart], [DayEnd], [WeekStart], [WeekEnd], [MonthStart], [MonthEnd], [YearStart], [YearEnd]
		 FROM @LogHits)

	OPEN TableCursor
	FETCH NEXT FROM TableCursor INTO @SiteID, @CodeName, @Culture, @ObjectName, @ObjectID, @Hits, @Value, 
									 @HourStart, @HourEnd, @DayStart, @DayEnd, @WeekStart, @WeekEnd, @MonthStart, @MonthEnd, @YearStart, @YearEnd
	WHILE @@FETCH_STATUS = 0
		BEGIN
			DECLARE @statisticsID int;
			SET @statisticsID = 0;
			SELECT TOP 1 @statisticsID = StatisticsID FROM [Analytics_Statistics]
			WHERE (StatisticsSiteID = @SiteID) 
				AND (StatisticsCode = @CodeName) 
				AND ((@ObjectName IS NOT NULL AND StatisticsObjectName = @ObjectName) OR (@ObjectName IS NULL AND StatisticsObjectName IS NULL)) 
				AND ((@ObjectID IS NOT NULL AND StatisticsObjectID = @ObjectID) OR (@ObjectID IS NULL AND StatisticsObjectID IS NULL)) 
				AND ((@Culture IS NOT NULL AND StatisticsObjectCulture = @Culture) OR (@Culture IS NULL AND StatisticsObjectCulture IS NULL));
	
			/* If @statisticsID is 0 insert new record */
			IF @statisticsID = 0
			BEGIN
				INSERT INTO [Analytics_Statistics] (StatisticsSiteID, StatisticsCode, StatisticsObjectName, StatisticsObjectID, StatisticsObjectCulture)
				VALUES (@SiteID, @CodeName, @ObjectName, @ObjectID, @Culture);

				SET @statisticsID = SCOPE_IDENTITY();
			END

	
			/* HOURS */	
			UPDATE [Analytics_HourHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value)
			WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@HourStart AND HitsEndTime=@HourEnd

			IF (@@ROWCOUNT = 0)
			BEGIN
				INSERT INTO [Analytics_HourHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
					   VALUES (@statisticsID,@HourStart,@HourEnd,@Hits,@Value);
			END

	
			/* DAYS */
			UPDATE [Analytics_DayHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value) 
			WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@DayStart AND HitsEndTime=@DayEnd;

			IF (@@ROWCOUNT = 0)
			BEGIN
				INSERT INTO [Analytics_DayHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
					   VALUES (@statisticsID,@DayStart,@DayEnd,@Hits,@Value);
			END

	
			/* WEEKS */
			UPDATE [Analytics_WeekHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value)
			WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@WeekStart AND HitsEndTime=@WeekEnd;

			IF (@@ROWCOUNT = 0)
			BEGIN
				INSERT INTO [Analytics_WeekHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
					   VALUES (@statisticsID,@WeekStart,@WeekEnd,@Hits,@Value);
			END

	
			/* MONTHS */
			UPDATE [Analytics_MonthHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value)
			WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@MonthStart AND HitsEndTime=@MonthEnd;

			IF (@@ROWCOUNT = 0)
			BEGIN
				INSERT INTO [Analytics_MonthHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
					   VALUES (@statisticsID,@MonthStart,@MonthEnd,@Hits,@Value);
			END

	
			/* YEARS */
			UPDATE [Analytics_YearHits] SET HitsCount=(HitsCount+@Hits), HitsValue=(ISNULL(HitsValue,0) + @Value) 
			WHERE HitsStatisticsID=@statisticsID AND HitsStartTime=@YearStart AND HitsEndTime=@YearEnd;

			IF (@@ROWCOUNT = 0)
			BEGIN
				INSERT INTO [Analytics_YearHits] ([HitsStatisticsID],[HitsStartTime],[HitsEndTime],[HitsCount],[HitsValue])
					   VALUES (@statisticsID,@YearStart,@YearEnd,@Hits,@Value);
			END

			FETCH NEXT FROM TableCursor INTO @SiteID, @CodeName, @Culture, @ObjectName, @ObjectID, @Hits, @Value, 
											 @HourStart, @HourEnd, @DayStart, @DayEnd, @WeekStart, @WeekEnd, 
											 @MonthStart, @MonthEnd, @YearStart, @YearEnd
		END
		
	CLOSE TableCursor
	DEALLOCATE TableCursor
END
GO
